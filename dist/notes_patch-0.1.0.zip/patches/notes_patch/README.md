# notes_patch

Patch MCP simples para gerenciar notas locais em texto.

Tools:
- notes.add    -> adiciona uma nova nota
- notes.list   -> lista notas existentes
- notes.search -> busca notas que contenham um termo
