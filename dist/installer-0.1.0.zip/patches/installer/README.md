# Installer Patch

Gerenciador de patches para AetherCore.

## Ferramentas

- `list_remote` - Lista patches no repositório
- `list_installed` - Lista patches instalados
- `install` - Instala patch: `{"patch_name": "echo"}`
- `uninstall` - Desinstala patch: `{"patch_name": "echo"}`
- `update` - Atualiza patch: `{"patch_name": "echo"}`

## Uso

```bash
# Listar patches remotos
run installer list_remote

# Instalar patch
run installer install patch_name="notes"

# Listar instalados
run installer list_installed

# Atualizar patch
run installer update patch_name="notes"

# Desinstalar
run installer uninstall patch_name="notes"

***

## 🎯 Testando no AetherCore

```bash
# 1. Listar patches remotos
aethercore> run installer list_remote
[
  {
    "name": "echo",
    "version": "0.1.0",
    "description": "...",
    "download_url": "..."
  },
  ...
]

# 2. Instalar patch
aethercore> run installer install patch_name="notes"
✅ Success
{
  "success": true,
  "message": "Patch 'notes' v0.1.0 instalado com sucesso"
}

# 3. Listar instalados
aethercore> run installer list_installed
[
  {
    "name": "notes",
    "version": "0.1.0",
    "path": "patches/notes"
  }
]

# 4. Atualizar
aethercore> run installer update patch_name="notes"
✅ Patch atualizado

# 5. Desinstalar
aethercore> run installer uninstall patch_name="notes"
✅ Patch desinstalado
