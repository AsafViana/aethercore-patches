#!/usr/bin/env python3
import sys
import json
import requests
import os
import zipfile
import shutil
import yaml
from pathlib import Path

# URL do repositório
PATCHES_REPO_URL = "https://raw.githubusercontent.com/AsafViana/aethercore-patches/refs/heads/main/generated/patches.json"

# IMPORTANTE: Usar caminhos ABSOLUTOS
# __file__ retorna o caminho absoluto do script
SCRIPT_DIR = Path(__file__).parent.resolve()  # .../patches/installer
PATCHES_DIR = SCRIPT_DIR.parent.resolve()     # .../patches

def send(obj):
    """Envia resposta JSON-RPC para stdout"""
    print(json.dumps(obj), flush=True)


def list_remote_patches():
    """Lista patches disponíveis no repositório remoto"""
    try:
        response = requests.get(PATCHES_REPO_URL, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        return {"error": f"Erro ao buscar patches: {str(e)}"}


def read_manifest(patch_dir):
    """Lê o manifest.yaml de um patch"""
    manifest_path = patch_dir / "manifest.yaml"
    
    if not manifest_path.exists():
        return None
    
    try:
        with open(manifest_path, 'r', encoding='utf-8') as f:
            manifest = yaml.safe_load(f)
            return {
                "name": manifest.get("name", patch_dir.name),
                "version": manifest.get("version", "unknown"),
                "transport": manifest.get("transport", "unknown"),
                "path": str(patch_dir)
            }
    except Exception as e:
        return None


def list_installed_patches():
    """Lista patches instalados localmente"""
    installed = []
    
    if not PATCHES_DIR.exists():
        print(f"⚠️  PATCHES_DIR não existe: {PATCHES_DIR}", file=sys.stderr)
        return installed
    
    for patch_dir in PATCHES_DIR.iterdir():
        if not patch_dir.is_dir():
            continue
        
        # Ignorar o próprio installer e pastas de sistema
        if patch_dir == SCRIPT_DIR or patch_dir.name in [".venv", "__pycache__", ".git", "node_modules"]:
            continue
        
        manifest_info = read_manifest(patch_dir)
        if manifest_info:
            installed.append(manifest_info)
    
    return installed


def install_patch(patch_name):
    """Instala um patch"""
    remote_patches = list_remote_patches()
    if "error" in remote_patches:
        return remote_patches
    
    patch_info = next((p for p in remote_patches if p["name"] == patch_name), None)
    if not patch_info:
        return {"error": f"Patch '{patch_name}' não encontrado no repositório"}
    
    download_url = patch_info["download_url"]
    
    # Usar caminhos ABSOLUTOS
    temp_zip = PATCHES_DIR / f"{patch_name}.zip"
    temp_extract_dir = PATCHES_DIR / f"_temp_{patch_name}"
    target_dir = PATCHES_DIR / patch_name
    
    print(f"📥 Baixando: {download_url}", file=sys.stderr)
    print(f"💾 Salvando em: {temp_zip}", file=sys.stderr)
    print(f"📂 Destino final: {target_dir}", file=sys.stderr)
    
    try:
        # Baixa o ZIP
        response = requests.get(download_url, timeout=30)
        response.raise_for_status()
        
        temp_zip.write_bytes(response.content)
        print(f"✅ Download: {temp_zip.stat().st_size} bytes", file=sys.stderr)
        
        # Remove versão antiga
        if target_dir.exists():
            print(f"🗑️  Removendo antiga: {target_dir}", file=sys.stderr)
            shutil.rmtree(target_dir)
        
        # Extrai para pasta temporária
        print(f"📦 Extraindo para: {temp_extract_dir}", file=sys.stderr)
        temp_extract_dir.mkdir(exist_ok=True)
        
        with zipfile.ZipFile(temp_zip, 'r') as zip_ref:
            zip_ref.extractall(temp_extract_dir)
        
        # Detecta estrutura do ZIP
        extracted_patch_dir = None
        
        if (temp_extract_dir / "patches" / patch_name).exists():
            extracted_patch_dir = temp_extract_dir / "patches" / patch_name
        elif (temp_extract_dir / patch_name).exists():
            extracted_patch_dir = temp_extract_dir / patch_name
        elif (temp_extract_dir / "manifest.yaml").exists():
            extracted_patch_dir = temp_extract_dir
        
        if not extracted_patch_dir or not extracted_patch_dir.exists():
            raise Exception(f"Estrutura do ZIP inválida")
        
        print(f"📂 Movendo de: {extracted_patch_dir}", file=sys.stderr)
        print(f"📂 Para: {target_dir}", file=sys.stderr)
        
        # Move para destino final
        shutil.move(str(extracted_patch_dir), str(target_dir))
        
        # Limpa temporários
        if temp_extract_dir.exists():
            shutil.rmtree(temp_extract_dir)
        temp_zip.unlink()
        
        print(f"✅ Instalado em: {target_dir}", file=sys.stderr)
        
        return {
            "success": True,
            "message": f"Patch '{patch_name}' v{patch_info['version']} instalado",
            "path": str(target_dir)
        }
        
    except Exception as e:
        print(f"❌ ERRO: {e}", file=sys.stderr)
        import traceback
        print(traceback.format_exc(), file=sys.stderr)
        
        # Limpa em caso de erro
        if temp_extract_dir.exists():
            shutil.rmtree(temp_extract_dir)
        if temp_zip.exists():
            temp_zip.unlink()
        
        return {"error": f"Erro ao instalar: {str(e)}"}


def uninstall_patch(patch_name):
    """Desinstala um patch"""
    target_dir = PATCHES_DIR / patch_name
    
    print(f"=" * 60, file=sys.stderr)
    print(f"🗑️  DESINSTALANDO: {patch_name}", file=sys.stderr)
    print(f"   PATCHES_DIR: {PATCHES_DIR}", file=sys.stderr)
    print(f"   target_dir: {target_dir}", file=sys.stderr)
    print(f"   Existe? {target_dir.exists()}", file=sys.stderr)
    
    if target_dir.exists():
        print(f"   É diretório? {target_dir.is_dir()}", file=sys.stderr)
        if target_dir.is_dir():
            print(f"   Conteúdo:", file=sys.stderr)
            for item in target_dir.iterdir():
                print(f"     - {item.name}", file=sys.stderr)
    
    print(f"=" * 60, file=sys.stderr)
    
    if not target_dir.exists():
        # Lista patches disponíveis
        available = [p.name for p in PATCHES_DIR.iterdir() if p.is_dir() and p != SCRIPT_DIR]
        return {
            "error": f"Patch '{patch_name}' não encontrado. Disponíveis: {', '.join(available)}"
        }
    
    try:
        print(f"🗑️  Removendo: {target_dir}", file=sys.stderr)
        shutil.rmtree(str(target_dir))  # Converte para string por segurança
        print(f"✅ Removido!", file=sys.stderr)
        return {
            "success": True,
            "message": f"Patch '{patch_name}' desinstalado"
        }
    except Exception as e:
        print(f"❌ ERRO: {e}", file=sys.stderr)
        import traceback
        print(traceback.format_exc(), file=sys.stderr)
        return {"error": f"Erro ao desinstalar: {str(e)}"}


def update_patch(patch_name):
    """Atualiza um patch"""
    installed = list_installed_patches()
    is_installed = any(p["name"] == patch_name for p in installed)
    
    if is_installed:
        uninstall_result = uninstall_patch(patch_name)
        if "error" in uninstall_result:
            return uninstall_result
    
    return install_patch(patch_name)


def sync_patch(patch_name):
    """Sincroniza (instala ou atualiza)"""
    return update_patch(patch_name)


def handle_request(req):
    """Processa requisição MCP"""
    method = req.get("method")
    params = req.get("params", {})
    req_id = req.get("id", 1)
    
    if method == "tools/list":
        result = {
            "tools": [
                {"name": "list_remote", "description": "Lista patches disponíveis", "parameters": {}},
                {"name": "list_installed", "description": "Lista patches instalados", "parameters": {}},
                {"name": "install", "description": "Instala patch", "parameters": {"patch_name": "string"}},
                {"name": "uninstall", "description": "Desinstala patch", "parameters": {"patch_name": "string"}},
                {"name": "update", "description": "Atualiza patch", "parameters": {"patch_name": "string"}},
                {"name": "sync", "description": "Sincroniza patch", "parameters": {"patch_name": "string"}}
            ]
        }
        return {"jsonrpc": "2.0", "id": req_id, "result": result}
    
    elif method == "tools/call":
        tool_name = params.get("name")
        arguments = params.get("arguments", {})
        
        if tool_name == "list_remote":
            result = list_remote_patches()
        elif tool_name == "list_installed":
            result = list_installed_patches()
        elif tool_name == "install":
            result = install_patch(arguments.get("patch_name", ""))
        elif tool_name == "uninstall":
            result = uninstall_patch(arguments.get("patch_name", ""))
        elif tool_name == "update":
            result = update_patch(arguments.get("patch_name", ""))
        elif tool_name == "sync":
            result = sync_patch(arguments.get("patch_name", ""))
        else:
            result = {"error": f"Tool '{tool_name}' não encontrada"}
        
        return {"jsonrpc": "2.0", "id": req_id, "result": result}
    
    else:
        return {"jsonrpc": "2.0", "id": req_id, "error": {"code": -32601, "message": f"Método inválido"}}


def main():
    """Loop MCP STDIO"""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        
        try:
            req = json.loads(line)
            resp = handle_request(req)
            send(resp)
        except json.JSONDecodeError as e:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(e)}})
        except Exception as e:
            send({"jsonrpc": "2.0", "id": None, "error": {"code": -32603, "message": str(e)}})


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ["test", "teste"]:
        print(json.dumps(list_remote_patches(), indent=2))
        print(json.dumps(list_installed_patches(), indent=2))
        print(json.dumps(install_patch('echo_patch'), indent=2))
        print(json.dumps(list_installed_patches(), indent=2))
        print(json.dumps(uninstall_patch('echo_patch'), indent=2))
    else:
        main()
