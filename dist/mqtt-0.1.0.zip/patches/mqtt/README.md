Bridge MQTT para o AetherCore, permitindo publicar e ler mensagens de um microcontrolador Wi‑Fi (ESP32/ESP8266 etc.) via MCP. [web:32]

## Ferramentas

- `mqtt_publish`  
  Publica uma mensagem em um tópico MQTT.

- `mqtt_subscribe_once`  
  Assina um tópico e retorna a primeira mensagem recebida (ou timeout). [web:32]

## Configuração

1. Crie o ambiente do patch com **uv**:

```bash
cd patches/mqttpatch

# Inicializa o projeto Python
uv init .

# Adiciona dependências
uv add paho-mqtt
```

O uv gerencia automaticamente um ambiente virtual isolado para o projeto e registra as dependências no arquivo de projeto. [web:36][web:37][web:39]

2. Ajuste o broker MQTT dentro de `server.py`:

```python
BROKER_HOST = "192.168.0.10"  # IP ou host do broker
BROKER_PORT = 1883
MQTT_CLIENT_ID = "aethercore_mqtt_client"
```

Use o IP/host e porta do mesmo broker que o seu microcontrolador Wi‑Fi está usando para publicar e assinar tópicos. [web:32][web:41]

3. Verifique se o `manifest.yaml` está apontando para o Python gerenciado pelo uv (script `python` dentro de `.venv` criado na pasta do patch):

- Windows:

```yaml
entrypoint:
  command: "patches/mqttpatch/.venv/Scripts/python.exe"
  args:
    - "patches/mqttpatch/server.py"
```

- Linux/macOS:

```yaml
entrypoint:
  command: "patches/mqttpatch/.venv/bin/python"
  args:
    - "patches/mqttpatch/server.py"
```

Esse padrão segue o mesmo formato de `entrypoint` do patch `installer`, apenas trocando o nome do patch e o caminho do interpretador. [file:34]

## Uso

Dentro do REPL do AetherCore:

```bash
# Publicar mensagem
aethercore> run mqtt mqtt_publish topic="esp32/cmd" payload="LED_ON"

# Ler próxima mensagem de um tópico
aethercore> run mqtt mqtt_subscribe_once topic="esp32/sensores" timeout=5
```

O cliente MQTT em `server.py` usa a biblioteca Paho para conectar ao broker, publicar mensagens e receber dados dos tópicos configurados. [web:32][web:41]

### Exemplo de fluxo

1. Microcontrolador:
   - Conecta ao broker MQTT.
   - Publica telemetria em `esp32/sensores`.
   - Assina comandos em `esp32/cmd`. [web:32]

2. AetherCore:
   - Usa `mqtt_publish` para mandar comandos (por exemplo, ligar/desligar LED).
   - Usa `mqtt_subscribe_once` para ler a próxima mensagem de telemetria. [web:32][web:41]

## Testando no AetherCore

```bash
# Listar tools do patch
aethercore> tools mqtt

# Chamar uma tool diretamente
aethercore> run mqtt mqtt_publish topic="test/topic" payload="hello"
```

Caso haja falha de conexão ou timeout, o `server.py` retorna um objeto JSON com `success: false` e detalhes do erro, conforme a lógica de tratamento de exceções implementada no servidor. [web:32]
```

[1](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_17c1d83a-cd71-4873-a93c-fdf3079d2600/46f4b5f8-718d-47a9-8a12-f59080972d5e/README.md)
[2](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/collection_17c1d83a-cd71-4873-a93c-fdf3079d2600/42f3671e-02f6-4fbc-8505-e2b357655349/file-tree.md)
[3](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/8059518/3c5fc863-2ad9-45ba-b661-9ba72a608ee6/README.md)
[4](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/8059518/87fac4f3-c0c0-461c-aebc-a92b16f7468e/manifest.yaml)
[5](https://ppl-ai-file-upload.s3.amazonaws.com/web/direct-files/attachments/8059518/58ab4707-6f1d-4ad8-a91a-3560881e9e0d/server.py)
[6](https://realpython.com/python-uv/)
[7](https://docs.astral.sh/uv/guides/projects/)
[8](https://www.datacamp.com/tutorial/python-uv)
[9](https://github.com/astral-sh/uv)
[10](https://astral.sh/blog/uv)
[11](https://dev.to/emqx/how-to-use-mqtt-in-python-paho-3b8)
[12](https://docs.cloud.google.com/dataflow/docs/guides/templates/provided/mqtt-to-pubsub)
[13](https://www.youtube.com/watch?v=AMdG7IjgSPM)
[14](http://www.steves-internet-guide.com/into-mqtt-python-client/)
[15](https://github.com/tigoe/mqtt-examples)
[16](https://www.youtube.com/watch?v=zgSQr0d5EVg)
[17](https://www.emqx.com/en/blog/how-to-use-mqtt-in-python)
[18](https://community.openhab.org/t/mqtt-update-readme-md-to-include-examples/83668/3)
[19](https://www.saaspegasus.com/guides/uv-deep-dive/)
[20](https://cedalo.com/blog/configuring-paho-mqtt-python-client-with-examples/)