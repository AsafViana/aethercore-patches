#!/usr/bin/env python3
import sys
import json
import asyncio
from pathlib import Path

import paho.mqtt.client as mqtt

# Diretório do patch (patches/mqttpatch)
SCRIPT_DIR = Path(__file__).parent.resolve()

# Configuração MQTT (ajuste para o seu broker)
BROKER_HOST = "192.168.0.10"  # IP ou host do broker
BROKER_PORT = 1883
MQTT_CLIENT_ID = "aethercore_mqtt_client"

_loop = asyncio.new_event_loop()
asyncio.set_event_loop(_loop)
_client = None
_sub_futures = {}


def send(obj: dict) -> None:
    """Envia resposta JSON-RPC para stdout."""
    print(json.dumps(obj), flush=True)


def _get_client() -> mqtt.Client:
    """Inicializa (se necessário) e retorna o cliente MQTT."""
    global _client

    if _client is not None:
        return _client

    client = mqtt.Client(client_id=MQTT_CLIENT_ID)

    def on_connect(c, userdata, flags, rc, properties=None):
        sys.stderr.write(f"[MQTT] Conectado ao broker {BROKER_HOST}:{BROKER_PORT} (rc={rc})\n")

    def on_disconnect(c, userdata, rc, properties=None):
        sys.stderr.write(f"[MQTT] Desconectado (rc={rc})\n")

    def on_message(c, userdata, msg):
        topic = msg.topic
        payload = msg.payload.decode("utf-8", errors="replace")
        sys.stderr.write(f"[MQTT] Mensagem em {topic}: {payload}\n")

        fut = _sub_futures.get(topic)
        if fut and not fut.done():
            fut.set_result(
                {
                    "topic": topic,
                    "payload": payload,
                    "qos": msg.qos,
                }
            )

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.on_message = on_message

    client.connect(BROKER_HOST, BROKER_PORT)
    client.loop_start()

    _client = client
    return _client


def tool_mqtt_publish(topic: str, payload: str, qos: int = 0, retain: bool = False) -> dict:
    """Tool: publica uma mensagem MQTT em um tópico."""
    client = _get_client()
    info = client.publish(topic, payload, qos=qos, retain=retain)
    return {
        "success": True,
        "topic": topic,
        "payload": payload,
        "qos": qos,
        "retain": retain,
        "mid": info.mid,
    }


def tool_mqtt_subscribe_once(topic: str, timeout: float = 5.0) -> dict:
    """Tool: assina um tópico e retorna a primeira mensagem recebida ou timeout."""
    client = _get_client()

    fut = _loop.create_future()
    _sub_futures[topic] = fut

    client.subscribe(topic, qos=0)

    try:
        result = _loop.run_until_complete(asyncio.wait_for(fut, timeout=timeout))
        return {
            "success": True,
            "message": result,
        }
    except asyncio.TimeoutError:
        return {
            "success": False,
            "error": "timeout",
            "topic": topic,
        }
    finally:
        _sub_futures.pop(topic, None)
        client.unsubscribe(topic)


def handle_request(req: dict) -> dict:
    """Processa requisição MCP (JSON-RPC)."""
    method = req.get("method")
    params = req.get("params", {})
    req_id = req.get("id", 1)

    if method == "tools/list":
        result = {
            "tools": [
                {
                    "name": "mqtt_publish",
                    "description": "Publica uma mensagem em um tópico MQTT",
                    "parameters": {
                        "topic": "string",
                        "payload": "string",
                        "qos": "int opcional",
                        "retain": "bool opcional",
                    },
                },
                {
                    "name": "mqtt_subscribe_once",
                    "description": "Assina um tópico MQTT e retorna a primeira mensagem recebida",
                    "parameters": {
                        "topic": "string",
                        "timeout": "float opcional (segundos)",
                    },
                },
            ]
        }
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    elif method == "tools/call":
        tool_name = params.get("name")
        arguments = params.get("arguments", {})

        if tool_name == "mqtt_publish":
            try:
                topic = arguments.get("topic", "")
                payload = arguments.get("payload", "")
                qos = int(arguments.get("qos", 0))
                retain = bool(arguments.get("retain", False))
                result = tool_mqtt_publish(topic, payload, qos=qos, retain=retain)
            except Exception as e:
                result = {"success": False, "error": str(e)}

        elif tool_name == "mqtt_subscribe_once":
            try:
                topic = arguments.get("topic", "")
                timeout = float(arguments.get("timeout", 5.0))
                result = tool_mqtt_subscribe_once(topic, timeout=timeout)
            except Exception as e:
                result = {"success": False, "error": str(e)}

        else:
            result = {"error": f"Tool '{tool_name}' não encontrada"}

        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    else:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": -32601, "message": "Método inválido"},
        }


def main() -> None:
    """Loop MCP STDIO."""
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            resp = handle_request(req)
            send(resp)
        except json.JSONDecodeError as e:
            send(
                {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32700, "message": str(e)},
                }
            )
        except Exception as e:
            send(
                {
                    "jsonrpc": "2.0",
                    "id": None,
                    "error": {"code": -32603, "message": str(e)},
                }
            )


if __name__ == "__main__":
    main()
