# echo_patch

Patch MCP de exemplo que expõe a tool `debug.echo`.

- `debug.echo` recebe `{ "text": "..." }` e devolve o mesmo texto.
"# Test update" 
